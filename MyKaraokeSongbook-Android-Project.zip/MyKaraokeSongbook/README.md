# MY KARAOKE SONGBOOK

**Developed by RINES DIY'ERS**

Offline Android songbook app built with Kotlin and the supplied SongHub SQLite song list.

## Included
- 47,998-song SQLite database in `app/src/main/assets/songhub_songbook.db`
- Search by song number, title, or artist
- Favorites saved locally on the phone
- Dark black / neon blue interface
- Microphone + music-notes vector launcher artwork
- About Developer screen and RINES DIY'ERS credit

## Build an APK on GitHub using a phone
1. Create a GitHub repository named `my-karaoke-songbook`.
2. Upload the **contents** of this project folder to the repository root (not the ZIP itself).
3. Open the repository's **Actions** tab.
4. Run the workflow named **Build Android APK** using **Run workflow**, or push a commit to the `main` branch.
5. Open the completed workflow run and download the `my-karaoke-songbook-debug-apk` artifact.
6. Extract the downloaded artifact ZIP and install the APK on your Android phone.

The workflow uses Gradle 8.9 and Android Gradle Plugin 8.7.3.

## Local build
Open this folder in Android Studio, allow Gradle sync, then run `gradle assembleDebug`. The APK is created at `app/build/outputs/apk/debug/app-debug.apk`.

Application ID: `com.rines.mykaraokesongbook`
Minimum Android: 6.0 (API 23)
Target SDK: 35 (works on Android 10 and newer supported devices)

This is a songbook only. It does not send selections to SongHub PC or play karaoke tracks.

© 2026 RINES DIY'ERS. All rights reserved.
