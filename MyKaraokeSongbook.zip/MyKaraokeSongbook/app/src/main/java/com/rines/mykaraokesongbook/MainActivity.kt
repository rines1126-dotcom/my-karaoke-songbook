package com.rines.mykaraokesongbook

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

private const val BG = 0xFF080B10.toInt()
private const val PANEL = 0xFF141C27.toInt()
private const val CYAN = 0xFF19D9FF.toInt()
private const val WHITE = 0xFFF4F8FC.toInt()
private const val MUTED = 0xFF9AA9B9.toInt()

class SongDb(context: Context) {
    private val db: SQLiteDatabase
    init {
        val file = context.getDatabasePath("songhub_songbook.db")
        if (!file.exists()) {
            file.parentFile?.mkdirs()
            context.assets.open("songhub_songbook.db").use { input -> file.outputStream().use { output -> input.copyTo(output) } }
        }
        db = SQLiteDatabase.openDatabase(file.absolutePath, null, SQLiteDatabase.OPEN_READONLY)
    }
    fun count(): Int = db.rawQuery("SELECT COUNT(*) FROM songs", null).use { if (it.moveToFirst()) it.getInt(0) else 0 }
    fun search(q: String, limit: Int = 250): List<Song> {
        val sql = if (q.isBlank()) "SELECT NUMBER,TITLE,ARTIST,CATEGORY FROM songs ORDER BY CAST(NUMBER AS INTEGER) LIMIT ?"
                  else "SELECT NUMBER,TITLE,ARTIST,CATEGORY FROM songs WHERE NUMBER LIKE ? OR TITLE LIKE ? OR ARTIST LIKE ? ORDER BY TITLE COLLATE NOCASE LIMIT ?"
        val args = if (q.isBlank()) arrayOf(limit.toString()) else arrayOf("%$q%", "%$q%", "%$q%", limit.toString())
        val result = mutableListOf<Song>()
        db.rawQuery(sql, args).use { c -> while (c.moveToNext()) result.add(Song(c.getString(0), c.getString(1), c.getString(2), c.getString(3))) }
        return result
    }
}
data class Song(val number: String, val title: String, val artist: String, val category: String)

class MainActivity : Activity() {
    private lateinit var database: SongDb
    private lateinit var list: LinearLayout
    private lateinit var search: EditText
    private lateinit var countLabel: TextView
    private lateinit var resultLabel: TextView
    private val favorites = mutableSetOf<String>()
    private var showingFavorites = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG; window.navigationBarColor = BG
        database = SongDb(this)
        favorites.addAll(getSharedPreferences("prefs", MODE_PRIVATE).getStringSet("favorites", emptySet()) ?: emptySet())
        buildScreen()
        render("")
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, radius: Int = 18): GradientDrawable = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView = TextView(this).apply {
        text = value; textSize = size; setTextColor(color); if (bold) setTypeface(null, Typeface.BOLD)
    }
    private fun buildScreen() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG); setPadding(dp(18), dp(18), dp(18), dp(8)) }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val heading = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        heading.addView(text("MY KARAOKE", 24f, WHITE, true))
        heading.addView(text("SONGBOOK  •  OFFLINE", 11f, CYAN, true))
        val developerCredit = text("DEVELOPED BY RINES DIY'ERS", 10f, MUTED, true).apply {
            setPadding(0, dp(5), 0, 0)
            setOnClickListener { showAboutDeveloper() }
        }
        heading.addView(developerCredit)
        header.addView(heading, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(text("♫", 38f, CYAN, true))
        root.addView(header)

        val stats = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = rounded(PANEL, 18); setPadding(dp(16), dp(14), dp(16), dp(14)) }
        countLabel = text("47,998 SONGS", 20f, WHITE, true)
        stats.addView(countLabel)
        stats.addView(text("Search your karaoke collection", 12f, MUTED))
        val statParams = LinearLayout.LayoutParams(-1, -2); statParams.topMargin = dp(18); root.addView(stats, statParams)

        search = EditText(this).apply {
            hint = "Search song number, title or artist..."; setHintTextColor(MUTED); setTextColor(WHITE); textSize = 15f
            setSingleLine(true); background = rounded(0xFF1A2634.toInt(), 14); setPadding(dp(15), 0, dp(15), 0)
        }
        val searchParams = LinearLayout.LayoutParams(-1, dp(52)); searchParams.topMargin = dp(14); root.addView(search, searchParams)
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val allBtn = Button(this).apply { text = "ALL SONGS"; setTextColor(CYAN); setBackgroundColor(Color.TRANSPARENT); setOnClickListener { showingFavorites = false; render(search.text.toString()) } }
        val favBtn = Button(this).apply { text = "♥ FAVORITES"; setTextColor(WHITE); setBackgroundColor(Color.TRANSPARENT); setOnClickListener { showingFavorites = true; render(search.text.toString()) } }
        tabs.addView(allBtn); tabs.addView(favBtn); root.addView(tabs)
        resultLabel = text("SONG LIST", 12f, CYAN, true); root.addView(resultLabel)
        val scroll = ScrollView(this).apply { isFillViewport = true }
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(text("© 2026 RINES DIY'ERS  •  ABOUT DEVELOPER", 10f, MUTED).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(4))
            setOnClickListener { showAboutDeveloper() }
        })
        setContentView(root)
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { render(s?.toString() ?: "") }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun showAboutDeveloper() {
        val message = "MY KARAOKE SONGBOOK\nVersion 1.0\n\nDeveloped by RINES DIY'ERS\n\nOffline karaoke songbook with search by song number, title, and artist.\n\n© 2026 RINES DIY'ERS"
        android.app.AlertDialog.Builder(this)
            .setTitle("About Developer")
            .setMessage(message)
            .setPositiveButton("CLOSE", null)
            .show()
    }

    private fun render(query: String) {
        list.removeAllViews()
        val songs = database.search(query).filter { !showingFavorites || favorites.contains(it.number) }
        resultLabel.text = if (showingFavorites) "FAVORITES (${songs.size})" else "SONG LIST (${songs.size}${if (query.isNotBlank()) "+" else ""})"
        countLabel.text = "${String.format("%,d", database.count())} SONGS"
        if (songs.isEmpty()) {
            list.addView(text(if (showingFavorites) "No favorite songs yet. Tap ♥ on a song." else "No matching songs found.", 14f, MUTED).apply { setPadding(dp(8), dp(24), dp(8), dp(24)) })
        }
        songs.forEach { song ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; background = rounded(PANEL, 14); setPadding(dp(12), dp(10), dp(8), dp(10)) }
            val number = text(song.number, 12f, CYAN, true).apply { minWidth = dp(58) }
            val details = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            details.addView(text(song.title, 14f, WHITE, true))
            details.addView(text(song.artist.ifBlank { "Unknown artist" }, 12f, MUTED))
            row.addView(number)
            row.addView(details, LinearLayout.LayoutParams(0, -2, 1f))
            val heart = TextView(this).apply { text = if (favorites.contains(song.number)) "♥" else "♡"; textSize = 25f; setTextColor(if (favorites.contains(song.number)) CYAN else MUTED); gravity = Gravity.CENTER; setPadding(dp(8), 0, dp(4), 0) }
            heart.setOnClickListener {
                if (!favorites.add(song.number)) favorites.remove(song.number)
                getSharedPreferences("prefs", MODE_PRIVATE).edit().putStringSet("favorites", favorites.toSet()).apply()
                render(search.text.toString())
            }
            row.addView(heart)
            val params = LinearLayout.LayoutParams(-1, -2); params.bottomMargin = dp(8); list.addView(row, params)
        }
    }
}
